import { getItem, updateItem, scanItems } from 'simple-dynamodb'
import { ItemList, AttributeMap } from 'aws-sdk/clients/dynamodb'

async function allPages(): Promise<ItemList | undefined> {
  const result = await scanItems({
    TableName: process.env.PAGE_TABLE!
  })

  return result.Items
}

async function page(parent, args): Promise<AttributeMap | undefined> {
  const { userId, pageId } = args
  const result = await getItem({
    TableName: process.env.PAGE_TABLE!,
    Key: {
      userId,
      pageId
    }
  })

  return result.Item
}

export { allPages, page }
